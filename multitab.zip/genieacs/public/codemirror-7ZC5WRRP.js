import{a}from"./chunk-5CVERMWV.js";import"./chunk-CDG7S4P5.js";export default a();
//# sourceMappingURL=codemirror-7ZC5WRRP.js.map
